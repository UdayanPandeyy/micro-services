package com.Repos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.Entities.CustomerModel;

public interface CustomerRepository extends CrudRepository<CustomerModel, Integer> {
	

}
