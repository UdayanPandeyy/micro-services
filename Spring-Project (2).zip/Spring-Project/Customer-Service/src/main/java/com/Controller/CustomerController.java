package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Entities.CustomerModel;
import com.Services.CustomerService;

public class CustomerController {
	
	@Autowired
	CustomerService customerservice;
	
	
	@PostMapping("/customer-service/")
	public int postingCustomerValue(@RequestBody CustomerModel customers ) {

		customerservice.saveOrUpdate(customers);
		return customers.customerID;

	}
	
	@PutMapping("/customer-service")
	public CustomerModel update(@RequestBody CustomerModel customers) {
		
		customerservice.saveOrUpdate(customers);
		return customers;
		
	}
	
	@GetMapping("customer/{customerid}")
	public CustomerModel getCustomers(@PathVariable("customerID") int customerID ){
		return customerservice.getCustomerById(customerID);
		
	}
	@DeleteMapping("customer/{customerid}" )
	public void deletecustomer(@PathVariable("customerID") int customerID) {
		 customerservice.delete(customerID);
		
	}
	



}
