package com.Entities;

import javax.persistence.Column;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

public class CustomerModel {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="customerid")
	int customerID;
	
	@Column(name="customer_name")
	String customerName;
	
	@Column(name="customer_type")
	String customerType;
	
	@Column(name="address1")
	String Address1;
	
	@Column(name="address2")
	String Address2;
	
	@Column(name="city")
	String City;
	
	@Column(name="state")
	String State;
	
	@Column(name="postal_code")
	int PostalCode;
	
	@Column(name="country")
	String Country;
	
	@Column(name="email")
	String EMail;
	
	@Column(name="phone")
	int Phone;
	@Column(name="fax")
	String Fax;

	
	
	public CustomerModel(){
		
	}
	
	
	public CustomerModel(int customerID, String customerName, String customerType, String address1,
			String address2, String city, String state, int postalCode, String country, String eMail, int phone,
			String fax) {
		super();
		this.customerID = customerID;
		this.customerName = customerName;
		this.customerType = customerType;
		Address1 = address1;
		Address2 = address2;
		City = city;
		State = state;
		PostalCode = postalCode;
		Country = country;
		EMail = eMail;
		Phone = phone;
		Fax = fax;
	}


	public int getCustomerID() {
		return customerID;
	}


	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getCustomerType() {
		return customerType;
	}


	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}


	public String getAddress1() {
		return Address1;
	}


	public void setAddress1(String address1) {
		Address1 = address1;
	}


	public String getAddress2() {
		return Address2;
	}


	public void setAddress2(String address2) {
		Address2 = address2;
	}


	public String getCity() {
		return City;
	}


	public void setCity(String city) {
		City = city;
	}


	public String getState() {
		return State;
	}


	public void setState(String state) {
		State = state;
	}


	public int getPostalCode() {
		return PostalCode;
	}


	public void setPostalCode(int postalCode) {
		PostalCode = postalCode;
	}


	public String getCountry() {
		return Country;
	}


	public void setCountry(String country) {
		Country = country;
	}


	public String getEMail() {
		return EMail;
	}


	public void setEMail(String eMail) {
		EMail = eMail;
	}


	public int getPhone() {
		return Phone;
	}


	public void setPhone(int phone) {
		Phone = phone;
	}


	public String getFax() {
		return Fax;
	}


	public void setFax(String fax) {
		Fax = fax;
	}
	
	
	
	
	
}
