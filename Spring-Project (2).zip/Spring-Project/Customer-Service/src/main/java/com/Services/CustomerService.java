package com.Services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Entities.CustomerModel;
import com.Repos.CustomerRepository;

@Service
public class CustomerService {
	
	@Autowired
	CustomerRepository customerrepository;
	
	public List<CustomerModel> getallcustomer(){
		List<CustomerModel> customers= new ArrayList<CustomerModel>();
		customerrepository.findAll().forEach(customers1->customers.add(customers1));
		return customers ;
		
	}
	
	public CustomerModel getCustomerById(int id) {
		return customerrepository.findById(id).get();
		
	}
	
	public void saveOrUpdate(CustomerModel customers) {
		customerrepository.save(customers);
	}
	
	public void delete(int id) {
		customerrepository.deleteById(id);
	}
	
	public void update(CustomerModel customers, int customerid) {
		customerrepository.save(customers);
	}
	

	
}
