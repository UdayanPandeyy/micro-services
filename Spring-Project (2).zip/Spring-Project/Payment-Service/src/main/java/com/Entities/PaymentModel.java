package com.Entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.ValuObject.CustomerModel;


@Entity
public class PaymentModel {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="paymentId")
	int paymentId;
	
	 @Column(name="amount")
	double Amount;
	 
	 @Column(name="credit_type")
	String creditType;
	 
	 @Column(name="discription")
	String Discription;
	
	@OneToMany(targetEntity=CustomerModel.class)
	int customerID;
	
	public PaymentModel() {
		
	}

	public PaymentModel(int paymentId, double amount, String creditType, String discription, int customerID) {
		super();
		this.paymentId = paymentId;
		Amount = amount;
		this.creditType = creditType;
		Discription = discription;
		this.customerID = customerID;
	}

	public int getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(int paymentId) {
		this.paymentId = paymentId;
	}

	public double getAmount() {
		return Amount;
	}

	public void setAmount(double amount) {
		Amount = amount;
	}

	public String getCreditType() {
		return creditType;
	}

	public void setCreditType(String creditType) {
		this.creditType = creditType;
	}

	public String getDiscription() {
		return Discription;
	}

	public void setDiscription(String discription) {
		Discription = discription;
	}

	public int getCustomerId() {
		return customerID;
	}

	public void setCustomerId(int customerId) {
		this.customerID = customerId;
	}
	
	

}
