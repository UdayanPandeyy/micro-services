package com.Services;

import org.springframework.beans.factory.annotation.Autowired;

import com.Entities.PaymentModel;
import com.Repos.PaymentRepository;

import com.ValuObject.ResponseTemplateVO;
public class PaymentService {

	
    @Autowired
	PaymentRepository paymentrepository;
	
	
	public void saveOrUpdate(PaymentModel payments) {
		// TODO Auto-generated method stub
		paymentrepository.save(payments);
		
	}
	
	
	 public ResponseTemplateVO getUserWithDepartment(int paymentIdId) {
	        ResponseTemplateVO vo = new ResponseTemplateVO();
	        PaymentModel payment = paymentrepository.findBypaymentId(paymentIdId);

	        CustomerModel customer =
	                restTemplate.getForObject("http://CUSTOMER-SERVICE/customers/" + payment.getCustomerID()
	                        ,CustomerModel.class);

	        vo.PaymentModel(payment);
	        vo.CustomerModel(customer);

	        return  vo;
	    }

	public PaymentModel getCustomerById(int paymentId) {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(int paymentId) {
		// TODO Auto-generated method stub
		
	}

}
