package com.Repos;



import org.springframework.data.repository.CrudRepository;

import com.Entities.PaymentModel;

public interface PaymentRepository extends CrudRepository<PaymentModel, Integer> {

	

}
