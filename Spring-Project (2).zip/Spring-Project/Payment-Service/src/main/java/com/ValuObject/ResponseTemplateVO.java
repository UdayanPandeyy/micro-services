package com.ValuObject;

import javax.persistence.Entity;

import com.Entities.PaymentModel;


@Entity
public class ResponseTemplateVO {
	
	private CustomerModel customer;
	private PaymentModel payment;
	public ResponseTemplateVO(CustomerModel customer, PaymentModel payment) {
		super();
		this.customer = customer;
		this.payment = payment;
	}
	public ResponseTemplateVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
