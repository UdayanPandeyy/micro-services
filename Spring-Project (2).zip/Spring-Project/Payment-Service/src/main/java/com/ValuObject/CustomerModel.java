package com.ValuObject;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;


@Entity
public class CustomerModel {
	
	int paymentId;
    double Amount;
    String creditType;
    String Discription;
	public CustomerModel(int paymentId, double amount, String creditType, String discription) {
		super();
		this.paymentId = paymentId;
		Amount = amount;
		this.creditType = creditType;
		Discription = discription;
	}
	public CustomerModel() {
		super();
		// TODO Auto-generated constructor stub
	}
}
