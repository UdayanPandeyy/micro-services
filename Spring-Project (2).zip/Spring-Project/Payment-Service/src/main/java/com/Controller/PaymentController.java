package com.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.Services.PaymentService;

public class PaymentController {
	
	@Autowired
	PaymentService paymentservice;
	
	@PostMapping("/payment-service/")
	public int paymentService(@RequestBody PaymentModel payments ) {

		paymentservice.saveOrUpdate(payments);
		return payments.paymentId;

	}
	
	@PutMapping("/payment-service")
	public PaymentModel update(@RequestBody PaymentModel payments) {
		
		paymentservice.saveOrUpdate(payments);
		return payments;
		
	}
	
	@GetMapping("payment/{paymentid}")
	public PaymentModel getPayments(@PathVariable("paymentId") int paymentId ){
		return paymentservice.getCustomerById(paymentId);
		
	}
	@DeleteMapping("payment/{paymentid}" )
	public void deletepayment(@PathVariable("paymentId") int paymentId) {
		paymentservice.delete(paymentId);
		
	}
	
	
	


}
